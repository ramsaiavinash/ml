const { app, BrowserWindow, ipcMain } = require('electron');
const path = require('path');

let mainWindow;

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1366,
    height: 860,
    minWidth: 1024,
    minHeight: 640,
    title: 'Alankar Pooja Stores',
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
    },
  });
  mainWindow.loadFile('index.html');
  mainWindow.setMenuBarVisibility(false);
}

app.whenReady().then(() => {
  createWindow();

  const db = require('./db');

  ipcMain.handle('db:getProducts',      ()            => db.getProducts());
  ipcMain.handle('db:insertProduct',    (_, p)        => db.insertProduct(p));
  ipcMain.handle('db:updateProduct',    (_, p)        => db.updateProduct(p));
  ipcMain.handle('db:deleteProduct',    (_, id)       => db.deleteProduct(id));
  ipcMain.handle('db:getProductByBC',   (_, bc)       => db.getProductByBarcode(bc));
  ipcMain.handle('db:saveBill',         (_, bill, items) => db.saveBill(bill, items));
  ipcMain.handle('db:getBills',         (_, f, t, m)  => db.getBills(f, t, m));
  ipcMain.handle('db:getBillItems',     (_, id)       => db.getBillItems(id));
  ipcMain.handle('db:getCustomers',     ()            => db.getCustomers());
  ipcMain.handle('db:insertCustomer',   (_, c)        => db.insertCustomer(c));
  ipcMain.handle('db:addStockEntry',    (_, e)        => db.addStockEntry(e));
  ipcMain.handle('db:getStockHistory',  ()            => db.getStockHistory());
  ipcMain.handle('db:recordCreditPay',  (_, p)        => db.recordCreditPayment(p));
  ipcMain.handle('db:getCreditEntries', ()            => db.getCreditEntries());
  ipcMain.handle('db:getCreditPayments',()            => db.getCreditPayments());
  ipcMain.handle('db:getDashStats',     ()            => db.getDashStats());
  ipcMain.handle('db:getGSTReport',     (_, month)    => db.getGSTReport(month));
  ipcMain.handle('db:getMonthlyReport', (_, month)    => db.getMonthlyReport(month));

  ipcMain.handle('print:html', (_, htmlContent) => {
    const win = new BrowserWindow({
      width: 420,
      height: 700,
      show: true,
      title: 'Print Bill',
      webPreferences: { nodeIntegration: false },
    });
    win.loadURL('data:text/html;charset=utf-8,' + encodeURIComponent(htmlContent));
    win.webContents.once('did-finish-load', () => {
      setTimeout(() => {
        win.webContents.print({ silent: false, printBackground: true }, (success) => {
          if (success) win.close();
        });
      }, 500);
    });
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});
app.on('activate', () => {
  if (BrowserWindow.getAllWindows().length === 0) createWindow();
});
