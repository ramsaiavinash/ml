# Alankar Pooja Stores — Sales Management App
## Setup Instructions (One-time only)

### Step 1 — Install Node.js
Download from: https://nodejs.org (choose LTS version)
Install it normally. Restart your computer after.

### Step 2 — Open this folder in terminal
- Right-click on the `alankar-pooja-stores` folder
- Click "Open in Terminal" (or Command Prompt)

### Step 3 — Install dependencies
Run this command:
```
npm install
```
Wait for it to finish (may take 2-3 minutes first time).

### Step 4 — Run the app
```
npm start
```
The app will open as a desktop window!

---

## To build an installer (.exe for Windows)
```
npm run build-win
```
The installer will appear in the `dist/` folder.
Copy that `.exe` to any Windows PC and install it — no Node.js needed.

---

## Your data is stored at:
Windows: `C:\Users\YourName\AppData\Roaming\alankar-pooja-stores\alankar.db`
Mac:     `~/Library/Application Support/alankar-pooja-stores/alankar.db`

Backup this file regularly to a USB drive or Google Drive!

---

## Features
- New Bill with barcode scan, GST split (CGST/SGST), 4 payment modes
- Print receipt to any connected printer
- Product catalog with barcode generation & label printing
- Stock entry with supplier & invoice tracking
- Credit ledger — track dues and record payments
- GST reports by month (GSTR-ready)
- Sales report with date/mode filter and printing
- Monthly report — daily breakdown, payment mix, top products
- Customer management with loyalty tracking

GSTIN in bills: Edit `index.html` line with "36AABCA1234Z1Z5" and replace with your real GSTIN.
Store phone: Edit `index.html` and replace "9000000000" with your number.
