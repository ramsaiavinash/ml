const Database = require('better-sqlite3');
const path = require('path');
const { app } = require('electron');

const dbPath = path.join(app.getPath('userData'), 'alankar.db');
const db = new Database(dbPath);

db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

db.exec(`
  CREATE TABLE IF NOT EXISTS products (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    category TEXT DEFAULT 'Other',
    unit TEXT DEFAULT 'Piece',
    hsn TEXT DEFAULT '',
    gst_rate REAL DEFAULT 5,
    selling_price REAL NOT NULL,
    cost_price REAL DEFAULT 0,
    stock INTEGER DEFAULT 0,
    min_stock INTEGER DEFAULT 10,
    barcode TEXT UNIQUE,
    created_at TEXT DEFAULT (date('now'))
  );

  CREATE TABLE IF NOT EXISTS customers (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    phone TEXT UNIQUE,
    email TEXT DEFAULT '',
    address TEXT DEFAULT '',
    credit_balance REAL DEFAULT 0,
    total_purchases REAL DEFAULT 0,
    purchase_count INTEGER DEFAULT 0,
    status TEXT DEFAULT 'New',
    created_at TEXT DEFAULT (date('now'))
  );

  CREATE TABLE IF NOT EXISTS bills (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    bill_number TEXT UNIQUE,
    customer_name TEXT DEFAULT 'Walk-in',
    customer_phone TEXT DEFAULT '',
    subtotal REAL DEFAULT 0,
    cgst REAL DEFAULT 0,
    sgst REAL DEFAULT 0,
    discount REAL DEFAULT 0,
    total REAL DEFAULT 0,
    payment_mode TEXT DEFAULT 'Cash',
    bill_date TEXT DEFAULT (date('now')),
    bill_time TEXT DEFAULT (time('now'))
  );

  CREATE TABLE IF NOT EXISTS bill_items (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    bill_id INTEGER REFERENCES bills(id) ON DELETE CASCADE,
    product_id INTEGER REFERENCES products(id),
    product_name TEXT,
    hsn TEXT DEFAULT '',
    qty INTEGER DEFAULT 1,
    rate REAL DEFAULT 0,
    gst_rate REAL DEFAULT 0,
    base_amount REAL DEFAULT 0,
    gst_amount REAL DEFAULT 0,
    total_amount REAL DEFAULT 0
  );

  CREATE TABLE IF NOT EXISTS stock_entries (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    product_id INTEGER REFERENCES products(id),
    product_name TEXT,
    qty_added INTEGER DEFAULT 0,
    cost_price REAL DEFAULT 0,
    supplier TEXT DEFAULT '',
    invoice_no TEXT DEFAULT '',
    entry_date TEXT DEFAULT (date('now'))
  );

  CREATE TABLE IF NOT EXISTS credit_payments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    customer_phone TEXT,
    customer_name TEXT,
    amount REAL DEFAULT 0,
    payment_mode TEXT DEFAULT 'Cash',
    payment_date TEXT DEFAULT (date('now'))
  );
`);

// Seed sample products if empty
const count = db.prepare('SELECT COUNT(*) as c FROM products').get().c;
if (count === 0) {
  const seed = db.prepare(`INSERT INTO products (name,category,unit,hsn,gst_rate,selling_price,cost_price,stock,min_stock,barcode) VALUES (?,?,?,?,?,?,?,?,?,?)`);
  const seedData = [
    ['Agarbatti Premium Pack','Agarbatti & Dhoop','Pack','3307',5,45,28,120,20,'8901234567001'],
    ['Clay Diya Set of 10','Diyas & Lamps','Pack','6914',5,30,18,8,15,'8901234567002'],
    ['Kumkum Powder 50g','Camphor & Kumkum','Pack','3304',12,20,10,55,10,'8901234567003'],
    ['Camphor Tablets Box','Camphor & Kumkum','Box','2914',5,35,20,40,10,'8901234567004'],
    ['Tulsi Garland','Flowers & Garlands','Piece','0604',0,25,12,6,10,'8901234567005'],
    ['Brass Diya Small','Diyas & Lamps','Piece','8311',12,150,90,22,5,'8901234567006'],
    ['Puja Thali Set','Puja Thali','Piece','7323',12,350,200,12,3,'8901234567007'],
    ['Sandalwood Powder 100g','Camphor & Kumkum','Pack','3307',12,80,45,30,8,'8901234567008'],
    ['Cotton Wicks (100pcs)','Diyas & Lamps','Pack','5601',5,15,8,60,15,'8901234567009'],
    ['Coconut (Medium)','Coconut & Fruits','Piece','0801',0,30,18,25,10,'8901234567010'],
  ];
  const insertMany = db.transaction((rows) => rows.forEach(r => seed.run(...r)));
  insertMany(seedData);
}

// ── PRODUCTS ──
function getProducts() {
  return db.prepare('SELECT * FROM products ORDER BY name').all();
}
function getProductByBarcode(bc) {
  return db.prepare('SELECT * FROM products WHERE barcode = ?').get(bc) || null;
}
function insertProduct(p) {
  return db.prepare(`
    INSERT INTO products (name,category,unit,hsn,gst_rate,selling_price,cost_price,stock,min_stock,barcode)
    VALUES (@name,@category,@unit,@hsn,@gst_rate,@selling_price,@cost_price,@stock,@min_stock,@barcode)
  `).run(p);
}
function updateProduct(p) {
  return db.prepare(`
    UPDATE products SET name=@name, category=@category, unit=@unit, hsn=@hsn,
    gst_rate=@gst_rate, selling_price=@selling_price, cost_price=@cost_price,
    min_stock=@min_stock, barcode=@barcode WHERE id=@id
  `).run(p);
}
function deleteProduct(id) {
  return db.prepare('DELETE FROM products WHERE id = ?').run(id);
}

// ── BILLS ──
const saveBill = db.transaction((bill, items) => {
  const billNum = 'INV-' + String(Date.now()).slice(-6);
  const res = db.prepare(`
    INSERT INTO bills (bill_number,customer_name,customer_phone,subtotal,cgst,sgst,discount,total,payment_mode,bill_date,bill_time)
    VALUES (@bill_number,@customer_name,@customer_phone,@subtotal,@cgst,@sgst,@discount,@total,@payment_mode,@bill_date,@bill_time)
  `).run({ bill_number: billNum, ...bill });
  const billId = res.lastInsertRowid;

  const stmtItem = db.prepare(`
    INSERT INTO bill_items (bill_id,product_id,product_name,hsn,qty,rate,gst_rate,base_amount,gst_amount,total_amount)
    VALUES (@bill_id,@product_id,@product_name,@hsn,@qty,@rate,@gst_rate,@base_amount,@gst_amount,@total_amount)
  `);
  for (const item of items) {
    stmtItem.run({ bill_id: billId, ...item });
    db.prepare('UPDATE products SET stock = MAX(0, stock - ?) WHERE id = ?').run(item.qty, item.product_id);
  }

  if (bill.customer_phone) {
    const extra = bill.payment_mode === 'Credit' ? bill.total : 0;
    db.prepare(`
      INSERT INTO customers (name, phone, credit_balance, total_purchases, purchase_count, status)
      VALUES (@name, @phone, @credit, @total, 1, 'New')
      ON CONFLICT(phone) DO UPDATE SET
        name = @name,
        credit_balance = credit_balance + @credit,
        total_purchases = total_purchases + @total,
        purchase_count = purchase_count + 1,
        status = CASE WHEN purchase_count+1 >= 10 THEN 'Loyal'
                      WHEN purchase_count+1 >= 3 THEN 'Regular'
                      ELSE status END
    `).run({ name: bill.customer_name, phone: bill.customer_phone, credit: extra, total: bill.total });
  }

  return { billId, billNum };
});

function getBills(from, to, mode) {
  let q = 'SELECT * FROM bills WHERE bill_date BETWEEN ? AND ?';
  const params = [from, to];
  if (mode) { q += ' AND payment_mode = ?'; params.push(mode); }
  return db.prepare(q + ' ORDER BY id DESC').all(...params);
}
function getBillItems(billId) {
  return db.prepare('SELECT * FROM bill_items WHERE bill_id = ?').all(billId);
}

// ── CUSTOMERS ──
function getCustomers() {
  return db.prepare('SELECT * FROM customers ORDER BY name').all();
}
function insertCustomer(c) {
  return db.prepare(`
    INSERT OR IGNORE INTO customers (name, phone, email, address)
    VALUES (@name, @phone, @email, @address)
  `).run(c);
}

// ── STOCK ──
function addStockEntry(e) {
  db.prepare(`
    INSERT INTO stock_entries (product_id,product_name,qty_added,cost_price,supplier,invoice_no)
    VALUES (@product_id,@product_name,@qty_added,@cost_price,@supplier,@invoice_no)
  `).run(e);
  db.prepare('UPDATE products SET stock = stock + ? WHERE id = ?').run(e.qty_added, e.product_id);
  return { ok: true };
}
function getStockHistory() {
  return db.prepare('SELECT * FROM stock_entries ORDER BY id DESC LIMIT 200').all();
}

// ── CREDIT ──
function recordCreditPayment(p) {
  db.prepare(`
    INSERT INTO credit_payments (customer_phone,customer_name,amount,payment_mode)
    VALUES (@customer_phone,@customer_name,@amount,@payment_mode)
  `).run(p);
  db.prepare('UPDATE customers SET credit_balance = MAX(0, credit_balance - ?) WHERE phone = ?')
    .run(p.amount, p.customer_phone);
  return { ok: true };
}
function getCreditEntries() {
  return db.prepare(`
    SELECT b.*, COALESCE(cp.paid,0) as paid_amount, MAX(0,b.total-COALESCE(cp.paid,0)) as due_amount
    FROM bills b
    LEFT JOIN (SELECT bill_id, SUM(amount) as paid FROM credit_payments GROUP BY bill_id) cp ON cp.bill_id=b.id
    WHERE b.payment_mode='Credit'
    ORDER BY b.id DESC
  `).all();
}
function getCreditPayments() {
  return db.prepare('SELECT * FROM credit_payments ORDER BY id DESC').all();
}

// ── DASHBOARD ──
function getDashStats() {
  return {
    todaySales:   db.prepare("SELECT COALESCE(SUM(total),0) as v FROM bills WHERE bill_date=date('now')").get().v,
    todayCount:   db.prepare("SELECT COUNT(*) as v FROM bills WHERE bill_date=date('now')").get().v,
    monthSales:   db.prepare("SELECT COALESCE(SUM(total),0) as v FROM bills WHERE strftime('%Y-%m',bill_date)=strftime('%Y-%m','now')").get().v,
    monthCount:   db.prepare("SELECT COUNT(*) as v FROM bills WHERE strftime('%Y-%m',bill_date)=strftime('%Y-%m','now')").get().v,
    totalCredit:  db.prepare('SELECT COALESCE(SUM(credit_balance),0) as v FROM customers WHERE credit_balance>0').get().v,
    creditCount:  db.prepare('SELECT COUNT(*) as v FROM customers WHERE credit_balance>0').get().v,
    lowStock:     db.prepare('SELECT COUNT(*) as v FROM products WHERE stock < min_stock').get().v,
    recentBills:  db.prepare('SELECT * FROM bills ORDER BY id DESC LIMIT 8').all(),
    payMix:       db.prepare("SELECT payment_mode, COUNT(*) as cnt, SUM(total) as total FROM bills WHERE strftime('%Y-%m',bill_date)=strftime('%Y-%m','now') GROUP BY payment_mode").all(),
    topProducts:  db.prepare(`
      SELECT bi.product_name, SUM(bi.qty) as qty_sold, SUM(bi.total_amount) as revenue
      FROM bill_items bi
      JOIN bills b ON b.id=bi.bill_id
      WHERE strftime('%Y-%m',b.bill_date)=strftime('%Y-%m','now')
      GROUP BY bi.product_name ORDER BY revenue DESC LIMIT 5
    `).all(),
  };
}

// ── GST REPORT ──
function getGSTReport(month) {
  return db.prepare(`
    SELECT bi.gst_rate,
      SUM(bi.base_amount) as taxable,
      SUM(bi.gst_amount/2) as cgst,
      SUM(bi.gst_amount/2) as sgst,
      SUM(bi.gst_amount) as total_gst,
      COUNT(*) as txn_count
    FROM bill_items bi
    JOIN bills b ON b.id=bi.bill_id
    WHERE strftime('%Y-%m',b.bill_date)=?
    GROUP BY bi.gst_rate ORDER BY bi.gst_rate
  `).all(month);
}

// ── MONTHLY REPORT ──
function getMonthlyReport(month) {
  const bills = db.prepare("SELECT * FROM bills WHERE strftime('%Y-%m',bill_date)=? ORDER BY bill_date").all(month);
  const daily = db.prepare(`
    SELECT bill_date, COUNT(*) as cnt, SUM(total) as revenue, SUM(cgst+sgst) as gst
    FROM bills WHERE strftime('%Y-%m',bill_date)=? GROUP BY bill_date ORDER BY bill_date
  `).all(month);
  const payMix = db.prepare(`
    SELECT payment_mode, COUNT(*) as cnt, SUM(total) as amount
    FROM bills WHERE strftime('%Y-%m',bill_date)=? GROUP BY payment_mode
  `).all(month);
  const topProds = db.prepare(`
    SELECT bi.product_name, SUM(bi.qty) as qty, SUM(bi.total_amount) as revenue, SUM(bi.gst_amount) as gst
    FROM bill_items bi JOIN bills b ON b.id=bi.bill_id
    WHERE strftime('%Y-%m',b.bill_date)=?
    GROUP BY bi.product_name ORDER BY revenue DESC LIMIT 10
  `).all(month);
  return { bills, daily, payMix, topProds };
}

module.exports = {
  getProducts, getProductByBarcode, insertProduct, updateProduct, deleteProduct,
  saveBill, getBills, getBillItems,
  getCustomers, insertCustomer,
  addStockEntry, getStockHistory,
  recordCreditPayment, getCreditEntries, getCreditPayments,
  getDashStats, getGSTReport, getMonthlyReport,
};
