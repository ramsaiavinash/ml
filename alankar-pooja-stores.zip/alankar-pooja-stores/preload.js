const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('api', {
  // Products
  getProducts:        ()           => ipcRenderer.invoke('db:getProducts'),
  insertProduct:      (p)          => ipcRenderer.invoke('db:insertProduct', p),
  updateProduct:      (p)          => ipcRenderer.invoke('db:updateProduct', p),
  deleteProduct:      (id)         => ipcRenderer.invoke('db:deleteProduct', id),
  getProductByBC:     (bc)         => ipcRenderer.invoke('db:getProductByBC', bc),

  // Bills
  saveBill:           (bill, items)       => ipcRenderer.invoke('db:saveBill', bill, items),
  getBills:           (from, to, mode)    => ipcRenderer.invoke('db:getBills', from, to, mode),
  getBillItems:       (id)                => ipcRenderer.invoke('db:getBillItems', id),

  // Customers
  getCustomers:       ()    => ipcRenderer.invoke('db:getCustomers'),
  insertCustomer:     (c)   => ipcRenderer.invoke('db:insertCustomer', c),

  // Stock
  addStockEntry:      (e)   => ipcRenderer.invoke('db:addStockEntry', e),
  getStockHistory:    ()    => ipcRenderer.invoke('db:getStockHistory'),

  // Credit
  recordCreditPay:    (p)   => ipcRenderer.invoke('db:recordCreditPay', p),
  getCreditEntries:   ()    => ipcRenderer.invoke('db:getCreditEntries'),
  getCreditPayments:  ()    => ipcRenderer.invoke('db:getCreditPayments'),

  // Reports & dashboard
  getDashStats:       ()      => ipcRenderer.invoke('db:getDashStats'),
  getGSTReport:       (month) => ipcRenderer.invoke('db:getGSTReport', month),
  getMonthlyReport:   (month) => ipcRenderer.invoke('db:getMonthlyReport', month),

  // Print
  printHTML:          (html)  => ipcRenderer.invoke('print:html', html),
});
